This LiveStreamTest is the "release" version of Bruce's viewer based on the OVP LiveStream Akamai examples.

It is built using Flash CS4 from the FLA in this older and relies on some libraries in other folders (see the FLA ActionScript build paths)