-- MySQL dump 10.13  Distrib 5.1.48, for portbld-freebsd6.2 (amd64)
--
-- Host: localhost    Database: constellation
-- ------------------------------------------------------
-- Server version	5.1.48

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'awalkinmyshoes','awalkinmyshoes@constellation.tv','password','http://awalkinmyshoes.com');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (3,8,'awesome movie','2010-11-20 11:05:41','2010-11-20 11:05:41'),(4,15,'Blah blah blah','2010-11-20 11:24:01','2010-11-20 11:24:01'),(5,15,'trying another comment','2010-11-20 11:24:29','2010-11-20 11:24:29'),(6,15,'and again','2010-11-20 11:25:21','2010-11-20 11:25:21'),(7,14,'testing','2010-11-20 11:30:12','2010-11-20 11:30:12'),(8,5,'testing again','2010-11-20 14:33:05','2010-11-20 14:33:05');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `migration_version`
--

LOCK TABLES `migration_version` WRITE;
/*!40000 ALTER TABLE `migration_version` DISABLE KEYS */;
INSERT INTO `migration_version` VALUES (8);
/*!40000 ALTER TABLE `migration_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `movie`
--

LOCK TABLES `movie` WRITE;
/*!40000 ALTER TABLE `movie` DISABLE KEYS */;
INSERT INTO `movie` VALUES (1,'a walk in my shoes','<param name=\"movie\" value=\"http://jnjit.origindigital.com/com/flyover/bin-debug/FlyoverPlayer.swf?userToken=620E8377853BAE0AC52C5B291F1CF70A6DBEEEE0C4B33FACA22540E5577BEE06D7E2074B8696D642DBC08C800CC6AA87FAFE6568F669EEEF5197F48AC8478081&configURL=http://jnjit.origindigital.com/FlyoverInitv1.2.xml&cssURL=http://jnjit.origindigital.com/com/flyover/bin-debug/com/CSS/Schematics.swf&width=640&height=359&showTrac=false&isAuth=True&mode=QS&resizeButt=false&assetPath=http://jnjit.origindigital.com/com/flyover/bin-debug/com/&CID=6044585&autoPlay=false&qaMonitor=false&menuBackDoor=true&toggleBackDoor=false\"></param>\n\n<param NAME=wmode VALUE=transparent/></param>\n<param name=\"allowscriptaccess\" value=\"always\"></param>\n\n<embed src=\"http://jnjit.origindigital.com/com/flyover/bin-debug/FlyoverPlayer.swf?userToken=620E8377853BAE0AC52C5B291F1CF70A6DBEEEE0C4B33FACA22540E5577BEE06D7E2074B8696D642DBC08C800CC6AA87FAFE6568F669EEEF5197F48AC8478081&configURL=http://jnjit.origindigital.com/FlyoverInitv1.2.xml&cssURL=http://jnjit.origindigital.com/com/flyover/bin-debug/com/CSS/Schematics.swf&width=640&height=359&showTrac=false&isAuth=True&mode=QS&resizeButt=false&assetPath=http://jnjit.origindigital.com/com/flyover/bin-debug/com/&CID=6044585&autoPlay=false&qaMonitor=false&menuBackDoor=true&toggleBackDoor=false\" wmode=\"transparent\" allowscriptaccess=\"always\" allowfullscreen=\"true\" width=\"640\" height=\"359\"></embed>\n','2010-11-17 22:59:34','2010-11-17 22:59:34','belarus');
/*!40000 ALTER TABLE `movie` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
INSERT INTO `token` VALUES (1,'abc-123',1,1,'2010-11-17 22:26:55','2020-11-17 22:26:55','2010-11-17 22:26:55',100,8,5),(16,'1234',1,1,'2011-02-03 09:07:00','2012-06-09 06:05:00','2010-11-18 22:24:44',123,11,8),(61,'4635-92387',1,1,'2010-11-20 11:10:00','2010-11-27 11:20:00','2010-11-20 11:22:32',1,1,15),(62,'4635-31517',1,1,'2010-11-20 11:10:00','2010-11-27 11:20:00','2010-11-20 11:22:32',1,1,14),(63,'83ba-83030',1,1,'2010-11-20 12:09:00','2010-11-27 12:09:00','2010-11-20 12:10:43',1,0,19),(64,'83ba-58040',1,1,'2010-11-20 12:09:00','2010-11-27 12:09:00','2010-11-20 12:10:43',1,0,18);
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `token_bucket`
--

LOCK TABLES `token_bucket` WRITE;
/*!40000 ALTER TABLE `token_bucket` DISABLE KEYS */;
INSERT INTO `token_bucket` VALUES (1,1,1,1),(12,1,16,1),(57,1,61,1),(58,1,62,1),(59,1,63,1),(60,1,64,1);
/*!40000 ALTER TABLE `token_bucket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `token_history`
--

LOCK TABLES `token_history` WRITE;
/*!40000 ALTER TABLE `token_history` DISABLE KEYS */;
INSERT INTO `token_history` VALUES (50,16,'2010-11-20 10:19:32'),(51,16,'2010-11-20 11:05:05'),(52,61,'2010-11-20 11:23:44'),(53,62,'2010-11-20 11:29:07'),(54,16,'2010-11-20 13:37:50'),(55,1,'2010-11-20 14:32:54');
/*!40000 ALTER TABLE `token_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `viewer`
--

LOCK TABLES `viewer` WRITE;
/*!40000 ALTER TABLE `viewer` DISABLE KEYS */;
INSERT INTO `viewer` VALUES (5,1,'bob1'),(8,16,'max2'),(12,61,'Anonymous'),(13,62,'Anonymous'),(14,62,'James 2'),(15,61,'James 1'),(16,63,'Anonymous'),(17,64,'Anonymous'),(18,64,'cindy'),(19,63,'kate');
/*!40000 ALTER TABLE `viewer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-11-20 15:08:00
