<?php

/**
 * TokenHistory form base class.
 *
 * @method TokenHistory getObject() Returns the current form's model object
 *
 * @package    constellation
 * @subpackage form
 * @author     max@sigilsoftware.com
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BaseTokenHistoryForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'token_id'   => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Token'), 'add_empty' => false)),
      'updated_at' => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'token_id'   => new sfValidatorDoctrineChoice(array('model' => $this->getRelatedModelName('Token'))),
      'updated_at' => new sfValidatorDateTime(),
    ));

    $this->widgetSchema->setNameFormat('token_history[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'TokenHistory';
  }

}
