<?php

class MovieCommentForm extends BaseForm {
    
    public function configure() {
        $this->setWidgets(array(
            'comment' => new sfWidgetFormTextarea(array(), array('class' => 'textinput')),
            'movie_id' => new sfWidgetFormInputHidden(),
        ));
    }

}
