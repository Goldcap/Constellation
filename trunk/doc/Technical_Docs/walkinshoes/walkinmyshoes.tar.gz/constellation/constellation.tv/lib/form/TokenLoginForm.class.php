<?php

class TokenLoginForm extends BaseForm {
    
    public function configure() {
        $this->setWidgets(array(
            'token' => new sfWidgetFormInputText(array(), array('class' => 'textinput')),
            'client_id' => new sfWidgetFormInputHidden(),
        ));
    }

}
