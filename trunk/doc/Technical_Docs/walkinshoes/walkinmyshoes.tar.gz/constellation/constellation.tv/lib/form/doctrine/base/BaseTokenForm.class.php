<?php

/**
 * Token form base class.
 *
 * @method Token getObject() Returns the current form's model object
 *
 * @package    constellation
 * @subpackage form
 * @author     max@sigilsoftware.com
 * @version    SVN: $Id: sfDoctrineFormGeneratedTemplate.php 29553 2010-05-20 14:33:00Z Kris.Wallsmith $
 */
abstract class BaseTokenForm extends BaseFormDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'id'         => new sfWidgetFormInputHidden(),
      'token'      => new sfWidgetFormInputText(),
      'active'     => new sfWidgetFormInputText(),
      'client_id'  => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Client'), 'add_empty' => false)),
      'viewer_id'  => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Viewer'), 'add_empty' => true)),
      'uses'       => new sfWidgetFormInputText(),
      'total_uses' => new sfWidgetFormInputText(),
      'start_time' => new sfWidgetFormDateTime(),
      'end_time'   => new sfWidgetFormDateTime(),
      'created_at' => new sfWidgetFormDateTime(),
    ));

    $this->setValidators(array(
      'id'         => new sfValidatorChoice(array('choices' => array($this->getObject()->get('id')), 'empty_value' => $this->getObject()->get('id'), 'required' => false)),
      'token'      => new sfValidatorString(array('max_length' => 255)),
      'active'     => new sfValidatorInteger(array('required' => false)),
      'client_id'  => new sfValidatorDoctrineChoice(array('model' => $this->getRelatedModelName('Client'))),
      'viewer_id'  => new sfValidatorDoctrineChoice(array('model' => $this->getRelatedModelName('Viewer'), 'required' => false)),
      'uses'       => new sfValidatorInteger(),
      'total_uses' => new sfValidatorInteger(),
      'start_time' => new sfValidatorDateTime(),
      'end_time'   => new sfValidatorDateTime(),
      'created_at' => new sfValidatorDateTime(),
    ));

    $this->widgetSchema->setNameFormat('token[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Token';
  }

}
