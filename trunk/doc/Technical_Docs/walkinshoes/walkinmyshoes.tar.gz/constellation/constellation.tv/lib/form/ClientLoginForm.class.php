<?php

class CLientLoginForm extends BaseForm {
    
    public function configure() {
        $this->setWidgets(array(
            'username' => new sfWidgetFormInputText(array(), array('class' => 'textinput')),
            'password' => new sfWidgetFormInputPassword(),
            ));
    }

}
