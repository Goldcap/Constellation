<?php

/**
 * TokenBucket filter form base class.
 *
 * @package    constellation
 * @subpackage filter
 * @author     max@sigilsoftware.com
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseTokenBucketFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'movie_id'  => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Movie'), 'add_empty' => true)),
      'token_id'  => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Token'), 'add_empty' => true)),
      'client_id' => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Client'), 'add_empty' => true)),
    ));

    $this->setValidators(array(
      'movie_id'  => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Movie'), 'column' => 'id')),
      'token_id'  => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Token'), 'column' => 'id')),
      'client_id' => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Client'), 'column' => 'id')),
    ));

    $this->widgetSchema->setNameFormat('token_bucket_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'TokenBucket';
  }

  public function getFields()
  {
    return array(
      'id'        => 'Number',
      'movie_id'  => 'ForeignKey',
      'token_id'  => 'ForeignKey',
      'client_id' => 'ForeignKey',
    );
  }
}
