<?php

/**
 * Client filter form.
 *
 * @package    constellation
 * @subpackage filter
 * @author     max@sigilsoftware.com
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ClientFormFilter extends BaseClientFormFilter
{
  public function configure()
  {
  }
}
