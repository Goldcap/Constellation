<?php

/**
 * Viewer filter form base class.
 *
 * @package    constellation
 * @subpackage filter
 * @author     max@sigilsoftware.com
 * @version    SVN: $Id: sfDoctrineFormFilterGeneratedTemplate.php 29570 2010-05-21 14:49:47Z Kris.Wallsmith $
 */
abstract class BaseViewerFormFilter extends BaseFormFilterDoctrine
{
  public function setup()
  {
    $this->setWidgets(array(
      'token_id' => new sfWidgetFormDoctrineChoice(array('model' => $this->getRelatedModelName('Token'), 'add_empty' => true)),
      'name'     => new sfWidgetFormFilterInput(),
    ));

    $this->setValidators(array(
      'token_id' => new sfValidatorDoctrineChoice(array('required' => false, 'model' => $this->getRelatedModelName('Token'), 'column' => 'id')),
      'name'     => new sfValidatorPass(array('required' => false)),
    ));

    $this->widgetSchema->setNameFormat('viewer_filters[%s]');

    $this->errorSchema = new sfValidatorErrorSchema($this->validatorSchema);

    $this->setupInheritance();

    parent::setup();
  }

  public function getModelName()
  {
    return 'Viewer';
  }

  public function getFields()
  {
    return array(
      'id'       => 'Number',
      'token_id' => 'ForeignKey',
      'name'     => 'Text',
    );
  }
}
