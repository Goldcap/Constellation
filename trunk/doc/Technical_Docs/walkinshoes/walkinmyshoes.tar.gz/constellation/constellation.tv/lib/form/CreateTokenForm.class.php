<?php

class CreateTokenForm extends BaseForm {
    
    public function configure() {
        $this->setWidgets(array(
            //'token' => new sfWidgetFormInputText(array(), array('class' => 'textinput')),
            'count' => new sfWidgetFormInputText(array(), array('class' => 'reports')),
            'total_uses' => new sfWidgetFormInputText(array(), array('class' => 'reports')),
            'start_time' => new sfWidgetFormDateTime(array(), array('class' => 'reports')),
            'end_time' => new sfWidgetFormDateTime(array(), array('class' => 'reports')),
            'movie_id' => new sfWidgetFormInputHidden(),
            'client_id' => new sfWidgetFormInputHidden(),
        ));

        $this->widgetSchema->setLabels(array('start_time' => 'Start Time (Month/Day/Year Hour:Minute)', 'end_time' => 'End Time (Month/Day/Year Hour:Minute)'));

    }

}
