<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php include_http_metas() ?>
        <?php include_metas() ?>
        <?php include_title() ?>
        <!-- <link rel="shortcut icon" href="/favicon.ico" /> -->
        <?php include_stylesheets() ?>
        <?php include_javascripts() ?>

        <link href="/css/main_styles.css" rel="stylesheet" type="text/css" />
        <!--[if lte IE 6]>
            <link rel="stylesheet" href="/css/ie6.css" type="text/css">
        <![endif]-->

        <script language="javascript">
            function toggleDiv(enter){
                if(document.getElementById(enter).style.display == 'none'){
                    document.getElementById(enter).style.display = 'block';
                }else{
                    document.getElementById(enter).style.display = 'none';
                }
            }

            var timerID;
            function toggleDiv1(enter1){
                document.getElementById(enter1).style.display = 'block';
                setTimeout("HideTimedLayer()", 2000);
            }
            function HideTimedLayer(enter1) {  
                clearTimeout(timerID);
                document.getElementById("enter1").style.display = "none";
                document.getElementById("enter").style.display = "none";
            }
        </script>
    </head>

    <body>
        <?php echo $sf_content ?>
    </body>
</html>
