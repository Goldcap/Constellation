<?php

class reportsConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
