<?php
    if (strlen($message)) {
        echo $message;
    } 
?>

<form action="<?php echo url_for('/tokens/login', true) ?>" method="POST">
  <table>
    <?php echo $form ?>
    <tr>
      <td colspan="2">
        <input type="submit" value='login' />
      </td>
    </tr>
  </table>
</form>


