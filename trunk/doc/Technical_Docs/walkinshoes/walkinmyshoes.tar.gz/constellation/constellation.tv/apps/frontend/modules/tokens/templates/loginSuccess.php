
<div id="wrapper">
<div class="walmart"></div>
<div class="pic1"></div>
<div class="pic2"></div>



    <div id="content" class="one"></div>
    <div id="loginerror" class="loginerror">
    <?php
        if ($message) {
            echo '<font color="black"><b>' . $message . '</b></font>';
        }
    ?>
    </div>
    <!-- end content -->
    <a href="#" onmousedown="toggleDiv('enter');" class="button">click here to enter viewing code</a>


    <div id="enter" style="display:none">
        <form action="<?php echo url_for('/tokens/login', true) ?>" class="one" method="POST" name="login">
            <fieldset>
                <label>Please enter veiwing code here</label>
                <input type="text" name="token" id="token" />
                <input type="hidden" name="client_id" value="<?=$client_id;?>" id="client_id" />
                <strong><a href="javascript:document.login.submit();">click to submit</a></strong>
            </fieldset>
        </form>
    </div>
</div><!-- end wrapper -->

