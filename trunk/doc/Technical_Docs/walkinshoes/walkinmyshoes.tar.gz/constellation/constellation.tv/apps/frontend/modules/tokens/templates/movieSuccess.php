<div id="wrapper">
    <div class="walmart"></div>
	
	<div id="content" class="two">
        <div class="video_player">
            <?=$movie->getUrl();?>
        </div>
    </div><!-- end content -->

	<a href="javascript:;" onmousedown="toggleDiv('enter');" class="button2">click here to tell us your thoughts</a>
    
    <div id="enter1" style="display:none">
    	<p>Thank you for your feedback!</p>
    </div>  

    <div id="enter" style="display:none">
    	<form action="<?php echo url_for('/tokens/movie', true) ?>" name="comment" class="two" method="POST">
            <fieldset>
            	<textarea name="comment" cols="" rows=""></textarea>
                <input type="hidden" name="movie_id" value="<?=$movie->getId();?>" id="movie_id" />
                <strong><a href="#" onmousedown="toggleDiv1('enter1');document.comment.submit()">click to submit</a></strong>
            </fieldset>
        </form>
    </div>
</div><!-- end wrapper -->
