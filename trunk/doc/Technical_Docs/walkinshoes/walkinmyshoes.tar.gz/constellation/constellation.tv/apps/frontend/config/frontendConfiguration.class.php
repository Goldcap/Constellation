<?php

class frontendConfiguration extends sfApplicationConfiguration
{
    public function configure()
    {
    }

    public function configureDoctrine(Doctrine_Manager $manager) {
        if ($this->getEnvironment() != 'dev') {

  /*  
            //enable Doctrine query cache
            $queryCacheDriver = new Doctrine_Cache_Apc();
            $manager->setAttribute(Doctrine::ATTR_QUERY_CACHE, $queryCacheDriver);

            // enable memcache
            $resultsCacheDriver = null;
            $memcache_servers = sfConfig::get('app_memcache_pool');

            if ($memcache_servers) {
                $resultsCacheDriver = new Doctrine_Cache_Memcache(array(
                            'servers' => $memcache_servers,
                            'compression' => false
                            )
                        );
            }

            //enable Doctrine results cache
            if ($resultsCacheDriver) {
                $manager->setAttribute(Doctrine::ATTR_RESULT_CACHE, $resultsCacheDriver);
            }
   */ 
        }
    }


}
