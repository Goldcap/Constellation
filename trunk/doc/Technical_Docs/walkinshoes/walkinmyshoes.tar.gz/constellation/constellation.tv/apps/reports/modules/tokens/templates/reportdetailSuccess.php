<p><b>Welcome <?=$client->getName();?>!</b></p>

<?php
    if (strlen($message)) {
        echo $message;
    }
?>

<form action="<?php echo url_for('/tokens/reportdetail', true) ?>" method="POST">
    <input type="hidden" name="client_id" value="<?=$client->getId();?>">
    <table class="reports">
        <caption class="reports">Change Your Password</caption>

        <tr class="reports">
            <th class="reports">Old Password:</th>
            <td class="reports"><input type="password" name="old_password"></td>
        </tr>

        <tr class="reports">
            <th class="reports">New Password:</th>
            <td class="reports"><input type="password" name="new_password1"></td>
        </tr>

        <tr class="reports">
            <th class="reports">Confirm New Password:</th>
            <td class="reports"><input type="password" name="new_password2"></td>
        </tr>

        <tr class="reports">
            <td colspan="2" class="reports">
                <input type="submit" value='change' class="reports"/>
            </td>
        </tr>
    </table>
</form>
<br><br>

<form action="<?php echo url_for('/tokens/reportdetail', true) ?>" method="POST">
    <?=$form['movie_id']->render();?>
    <?=$form['client_id']->render();?>
    <table class="reports">
        <caption class="reports">Create new tokens for <b>"<?=$movie->getName();?>"</b></caption>

        <tr class="reports">
            <th class="reports">Amount:</th>
            <td class="reports"><?=$form['count']->render();?></td>
        </tr>

        <tr class="reports">
            <th class="reports">Number of Uses:</th>
            <td class="reports"><?=$form['total_uses']->render();?></td>
        </tr>

        <tr class="reports">
            <th class="reports">Valid From (m/d/y h:m):</th>
            <td class="reports"><?=$form['start_time']->render();?></td>
        </tr>

        <tr class="reports">
            <th class="reports">Valid Until  (m/d/y h:m):</th>
            <td class="reports"><?=$form['end_time']->render();?></td>
        </tr>

        <tr class="reports">
            <td colspan="2" class="reports">
                <input type="submit" value='create' class="reports"/>
            </td>
        </tr>
    </table>
</form>
<br><br>

<form action="<?=url_for('/tokens/updateviewer', true);?>" method="POST">
<table class="reports">
    <caption class="reports">The details for <b>"<?=$movie->getName();?>"</b></caption>
    <thead>
        <tr class="reports">
            <td class="reports">Token</td>
            <td class="reports">Times Used</td>
            <td class="reports">Viewer Name</td>
            <td class="reports">Comment</td>
            <td class="reports">Uses</td>
            <td class="reports">Valid From</td>
            <td class="reports">Valid Until</td>
            <td class="reports">Delete</td>
        </tr>
    </thead>
    <tbody>
<?
foreach ($tokenbucket as $bucket) {
    echo '<tr class="reports">';
    $token = $bucket->getToken();
    $history = $token->getTokenHistory();
    $viewer = $token->getViewer();
    
    echo '<td class="reports">' . $token->getToken() . '</td>';

    echo '<td class="reports">';
    foreach ($history as $hist) {
        echo $hist->getUpdatedAt() . '<br>';
    }
    echo '</td>';

    echo '<td class="reports"><input type="text" name="viewer_name[' . $viewer->getId() . ']" value="' . $viewer->getName() . '"><br>';
    
    $comment = '';
    $comments = array();
    if ($viewer->getComment()->count() > 0) {
        foreach ($viewer->getComment() as $c) {
            $comments[] = $c->getComment();
        }
        $comment = implode('<br><br>', $comments);
    }
    echo '<td class="reports">' . $comment . '</td>';

    echo '<td class="reports">' . $token->getUses() . '/' . $token->getTotalUses() . '</td>';

    echo '<td class="reports">' . $token->getStartTime() . '</td>';

    echo '<td class="reports">' . $token->getEndTime() . '</td>';

    echo '<td class="reports"><input type="checkbox" name="token_id[]" value="' . $token->getId() . '"></td>';

    echo '</tr>';
}
?>
        <tr class="reports">
            <td colspan="8" class="reports">
                <input type="submit" value='update' class="reports"/>
            </td>
        </tr>

    </tbody>
</form>
</table>


