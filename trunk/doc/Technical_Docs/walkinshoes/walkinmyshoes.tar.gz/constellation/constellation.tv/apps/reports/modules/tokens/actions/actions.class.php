<?php

/**
 * tokens actions.
 *
 * @package    constellation
 * @subpackage tokens
 * @author     max@sigilsoftware.com
 */
class tokensActions extends sfActions
{
    /**
     * Executes index action
     *
     * @param sfRequest $request A request object
     */
    public function executeIndex(sfWebRequest $request) {
        return $this->forward('tokens' , 'reportdetail');
    }

    public function executeLogout(sfWebRequest $request) {
    echo 'asd';exit;
        $this->getUser()->removeCredential('client');
        $this->getUser()->setAuthenticated(false);
        return $this->redirect('/tokens/login');
    }

    public function executeLogin(sfWebRequest $request) {
        $this->message = '';

        $client = ClientTable::retrieveBySubdomain($request->getUriPrefix());

        if (!$client instanceof Client) {
            $this->message = 'Client not found';
            error_log(__METHOD__ . ' ' . $this->message);
            return sfView::SUCCESS;
        }
        $this->form = new ClientLoginForm();

        if ($request->isMethod('post') && $request->getParameter('username', false) && $request->getParameter('password', false)) {
            $client = ClientTable::Login($request->getParameter('username'), $request->getParameter('password'), $this->getUser());
            if (!$client) {
                $this->message = 'Invalid password';
                return sfView::SUCCESS;
            }
            $movies = $client->getMovie();
            if ($movies->count() == 1) {
                $this->getUser()->setAttribute('movie_id', $movies->getFirst()->getId());
                return $this->redirect('/tokens/reportdetail');
            }
        }
    }

    public function executeReportdetail(sfWebRequest $request) {
        $this->client = CLientTable::getInstance()->findOneById($this->getUser()->getAttribute('client_id'));
        $this->movie = MovieTable::getInstance()->findOneById($this->getUser()->getAttribute('movie_id'));
        $this->tokenbucket = $this->movie->getTokenBucket();

        $this->message = $this->getUser()->getFlash('message');

        $this->form = new CreateTokenForm(array('movie_id' => $this->movie->getId(), 'client_id' => $this->client->getId()));
        $this->form->setDefault('start_time', time());
        $this->form->setDefault('end_time', time() + 60*60*24*7);

        if ($request->isMethod('post')) {
            if ($request->getParameter('old_password', false) && $request->getParameter('new_password1', false) && $request->getParameter('new_password2', false)) { 
                if ($this->client->getPassword() != $request->getParameter('old_password')) {
                    $this->message = 'Old password is invalid';
                    return sfView::SUCCESS;
                }
                if ($request->getParameter('new_password1') != $request->getParameter('new_password2')) {
                    $this->message = 'Passwords do not match';
                    return sfView::SUCCESS;
                }

                $this->client->setPassword($request->getParameter('new_password1'));
                $this->client->save();

                $this->getUser()->setFlash('message', 'Your password has been changed');

            } elseif ($request->getParameter('count', false)) {

                // @TODO should be done through a validator
                // @TODO could be done through symfony somehow 
                $time = $request->getParameter('start_time');
                $time = mktime($time['hour'], $time['minute'], 0, $time['month'], $time['day'], $time['year']);
                $start_time = date('Y-m-d H:i:s', $time);

                $time = $request->getParameter('end_time');
                $time = mktime($time['hour'], $time['minute'], 0, $time['month'], $time['day'], $time['year']);
                $end_time = date('Y-m-d H:i:s', $time);

                for ($i = 1; $i <= $request->getParameter('count'); $i++) {
                    $token = new Token();
                    $token->setToken(Token::generate());
                    $token->setClient($this->client);
                    $token->setUses(0);
                    $token->setTotalUses($request->getParameter('total_uses'));
                    $token->setStartTime($start_time);
                    $token->setEndTime($end_time);
                    $token->save();

                    $v = new Viewer();
                    $v->setName('Anonymous');
                    $v->setToken($token);
                    $v->save();

                    $token->setViewer($v);
                    $token->save();

                    $bucket = new TokenBucket();
                    $bucket->setClient($this->client);
                    $bucket->setMovie($this->movie);
                    $bucket->setToken($token);
                    $bucket->save();
                }

            } else {
                if ($request->getParameter('viewer_name', false)) {
                    $ids = $request->getParameter('viewer_name');

                    // @TODO: for some crazy reason IN query always returns 1 row..
                    //$viewers = ViewerTable::retrieveByIds(array_keys($ids));
                    foreach ($ids as $id=>$name) {
                        $v = ViewerTable::getInstance()->findOneById($id);
                        $v->setName($ids[$v->getId()]);
                        $v->save();
                    }
                }

                if ($request->getParameter('token_id', false)) {
                    $ids = $request->getParameter('token_id');

                    // @TODO: for some crazy reason IN query always returns 1 row..
                    //$tokens = TokenTable::getByIds($ids);
                    foreach ($ids as $id) {
                        $t = TokenTable::getInstance()->findOneById($id);
                        $t->delete();
                    }
                }
            }
            return $this->redirect('/tokens/reportdetail');
        }

        return sfView::SUCCESS;
    }

    // @TODO: this doesnt work somehow??? had to move it to reportdetail()
    public function executeUpdateviewer(sfWebRequest $request) {
        if ($request->isMethod('post')) {

            $token = TokenTable::getInstance()->findOneById($request->getParameter('token_id'));
            $v = ViewerTable::getInstance()->findOneById($request->getParameter('viewer_id'));
            if (!$v instanceof Viewer) {
                $v = new Viewer();
            }
            $v->setName($request->getParameter('viewer_name'));
            $v->setToken($token);
            $v->save();

            $token->setViewer($v);
            $token->save();
        }
        return $this->redirect('/tokens/reportdetail');
    }


}
