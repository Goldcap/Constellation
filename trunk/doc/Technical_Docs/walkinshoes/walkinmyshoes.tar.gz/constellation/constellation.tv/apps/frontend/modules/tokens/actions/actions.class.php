<?php

/**
 * tokens actions.
 *
 * @package    constellation
 * @subpackage tokens
 * @author     max@sigilsoftware.com
 */
class tokensActions extends sfActions
{
    /**
     * Executes index action
     *
     * @param sfRequest $request A request object
     */
    public function executeIndex(sfWebRequest $request) {

        return $this->forward('tokens', 'movie');

    }

    public function executeLogin(sfWebRequest $request) {
        $this->message = '';

        $client = ClientTable::retrieveBySubdomain($request->getUriPrefix());
        if (!$client instanceof Client) {
            $this->message = 'Client not found';
            error_log(__METHOD__ . ' ' . $this->message);
            return sfView::SUCCESS;
        }

        $this->client_id = $client->getId();
        $this->form = new TokenLoginForm(array('client_id' => $this->client_id));

        if ($request->isMethod('post') && $request->getParameter('token', false) && $request->getParameter('client_id', false)) {
            $token = TokenTable::retrieveByClientAndToken($request->getParameter('client_id'), $request->getParameter('token', false));
            if ($token instanceof Token && $token->authenticate($this->getUser())) {
                return $this->redirect('/tokens/movie');
            } else {
                $this->message =  'Your token is not valid';
            }
        }

        return sfView::SUCCESS;
    }

    public function executeMovie(sfWebRequest $request) {
        $this->message = '';
        $this->token_string = $this->getUser()->getAttribute('token');
        $this->client_id = $this->getUser()->getAttribute('client_id');

        $this->token = TokenTable::retrieveByClientAndToken($this->client_id, $this->token_string);

        if ($request->isMethod('post')) {
            $v = $this->token->getViewer();
            $c = new Comment();
            $c->setComment($request->getParameter('comment'));
            $c->setViewer($v);
            $c->save();
        }

        $bucket = TokenBucketTable::getInstance()->findOneByTokenId($this->token->getId());

        if ($bucket) {
            $this->movie = $bucket->getMovie();
            $this->comments_form = new MovieCommentForm(array('movie_id' => $this->movie->getId()));
        } else {
            $this->message = 'No movie found for the token';
        } 

        return sfView::SUCCESS;
    }
}
