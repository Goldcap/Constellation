Flash Entry Point Republish application for FMS 3.5
by Javier Peletier (jpeletie@akamai.com)
Akamai confidential. Customer NDA required.
AKAMAI CONTRIBUTION LICENSE: If you use or change this code, you accept to contribute the changes back to Akamai.

WARNING: This application is provided AS IS, without warranty of any kind.

This FMS application gets a Stream from an encoder and republishes it to an Akamai EntryPoint, authenticating accordingly.
config.asc file contains the parameters required to use this application


INSTALLATION

To install this application, simply copy the included folder to your Flash Media Server applications folder. You can rename the folder to anything you like.

Edit the configuration file "config.asc" to subscribe to the desired source stream and configure the Akamai entry point information.

If you want to do primary/backup streaming, it is recommended that you create another instance of this application in a different folder and change the AKAMAI_ENTRYPOINT_TYPE to "backup".

How to use:


1.- Review the configuration file "config.asc" and restart FMS
2.-Configure your encoder to point to a URL like:

FMS URL: rtmp://<FMS_IP_ADDRESS>/<APPLICATION>
Stream name:<AKAMAI_STREAM_NAME>

For example:

rtmp://172.16.0.5/eprepublish/
Stream Name: streamlive@4533

3.- Start encoding in your encoder machine. The encoder will connect to this FMS application, which in turn will authenticate and connect to Akamai.