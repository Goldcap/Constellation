# Copyright (c) Corporation for National Research Initiatives

# Driver script for jythonc2.  See module main.py for details
import main
main.main()

import os
os._exit(0)
