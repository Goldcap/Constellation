Welcome to Jython 2.2.1
=======================
This is the 2.2.1 release of Jython, an implementation of the Python
programming language on the Java Virtual Machine.  2.2.1 is a bugfix release
that takes care of all of the major bugs that have been reported since 2.2.
See the NEWS file for a more complete list of changes.

The release was compiled on Mac OS X with JDK 5 but it should run on an JVM
with version 1.4.2 or later.

Bug reports can be created at http://jython.org/bugs whereas more general
questions can be sent to the Jython-users mailing list, 
jython-users@lists.sourceforge.net.
