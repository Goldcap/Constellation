// Copyright 2000 Samuele Pedroni

package jxxload_help;

public interface JavaLoaderFactory {
    
    public ClassLoader makeLoader();

}
