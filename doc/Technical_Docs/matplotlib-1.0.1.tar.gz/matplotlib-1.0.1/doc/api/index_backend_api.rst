*******************
matplotlib backends
*******************

.. toctree::

   backend_bases_api.rst
   backend_gtkagg_api.rst
   backend_qt4agg_api.rst
   backend_wxagg_api.rst
   backend_pdf_api.rst
   dviread.rst
   type1font.rst
